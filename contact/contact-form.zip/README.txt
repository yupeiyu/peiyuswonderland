A Pen created at CodePen.io. You can find this one at http://codepen.io/PeterKullmann/pen/zlCaK.

 Almost close to the idea I sketched by hand before trying to code it.

I learned with the help of:
Team Treehouse,
http://codepen.io/rikschennink/pen/FHaLo
http://codepen.io/palimadra/pen/hIqyJ
http://codepen.io/leshields/pen/JtIAo